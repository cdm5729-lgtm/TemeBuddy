# 手机构建 APK 的说明（通过 GitHub Actions）

这个压缩包是 Android 源码，不是 APK。它附带 `.github/workflows/build-apk.yml`，用于在 GitHub 云端构建 debug APK。

## 重要限制
- 需要一个 GitHub 账号，并把 `TemeBuddy` 文件夹内的项目文件放进一个 GitHub 仓库的根目录。
- GitHub 手机网页对上传整个项目文件夹/ZIP 的支持有限；通常要先解压并逐个上传文件，或使用 GitHub 手机 App/其他支持上传文件夹的客户端。
- 上传后进入仓库的 Actions，选择 “Build Android APK”，点击 “Run workflow”。完成后打开该次运行，下载 `TemeBuddy-debug-apk` artifact；解压 artifact 得到 `app-debug.apk`。
- 这是 debug 测试包，不是 Play 商店发布包；首次安装时 Android 可能要求允许此来源安装未知应用。只安装自己构建并信任的 APK。
- 该项目当前聊天是离线演示，不含在线 AI API；开奖记录需手动输入。

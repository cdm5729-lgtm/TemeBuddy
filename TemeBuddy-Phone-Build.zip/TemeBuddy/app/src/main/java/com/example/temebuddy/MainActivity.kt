package com.example.temebuddy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF253047)
private val Mint = Color(0xFFBCEFE0)
private val Peach = Color(0xFFFFD9C8)
private val Paper = Color(0xFFFFFAF5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF397F72), background = Paper)) { BuddyApp() } }
    }
}

data class Trial(val issue: String, val pick: String, val result: Int, val date: String)

@Composable
fun BuddyApp() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("buddy", 0) }
    var tab by remember { mutableStateOf(0) }
    var trials by remember {
        mutableStateOf(run {
            val arr = JSONArray(prefs.getString("trials", "[]"))
            (0 until arr.length()).map { i -> arr.getJSONObject(i).let { Trial(it.optString("issue"), it.optString("pick"), it.optInt("result"), it.optString("date")) } }
        })
    }
    fun save(list: List<Trial>) {
        val arr = JSONArray(); list.forEach { t -> arr.put(JSONObject().put("issue", t.issue).put("pick", t.pick).put("result", t.result).put("date", t.date)) }
        prefs.edit().putString("trials", arr.toString()).apply(); trials = list
    }
    Scaffold(containerColor = Paper, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("💬") }, label = { Text("聊天") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("📊") }, label = { Text("统计") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("📒") }, label = { Text("日志") })
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)) {
                Mascot(); Spacer(Modifier.width(12.dp)); Column {
                    Text("特码小伙伴", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Text("一起研究，数据说话 ✨", color = Color(0xFF687386))
                }
            }
            when (tab) {
                0 -> ChatScreen()
                1 -> StatsScreen(trials)
                else -> LogScreen(trials, ::save)
            }
        }
    }
}

@Composable
fun Mascot() {
    Box(Modifier.size(76.dp).background(Mint, CircleShape), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp, 15.dp).background(Ink, RoundedCornerShape(5.dp))); Spacer(Modifier.width(13.dp)); Box(Modifier.size(10.dp, 15.dp).background(Ink, RoundedCornerShape(5.dp))) }
            Spacer(Modifier.height(6.dp)); Box(Modifier.width(25.dp).height(4.dp).background(Color(0xFF397F72), RoundedCornerShape(4.dp)))
        }
        Box(Modifier.align(Alignment.TopCenter).offset(y = 9.dp).size(7.dp).background(Peach, CircleShape))
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun ChatScreen() {
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("小伙伴：嗨！我能陪你分析频数、记录每期结果，还会拿随机选号做对照。历史数据不能保证下一期哦。") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("今日研究室", fontWeight = FontWeight.Bold, color = Ink)
            Text("🧪 先记录、后开奖、再复盘。猜中和没猜中都保留。", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF687386))
        }
        LazyColumn(Modifier.weight(1f, fill = true), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg -> Surface(color = if (msg.startsWith("你：")) Mint else Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp) { Text(msg, Modifier.fillMaxWidth().padding(12.dp), color = Ink) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("聊聊我们的研究…") }, shape = RoundedCornerShape(18.dp), maxLines = 3)
            Button(onClick = {
                val q = input.trim()
                if (q.isNotEmpty()) {
                    messages.add("你：$q")
                    messages.add("小伙伴：我先按统计原则回答：我们要固定选号规则、保留全部期数，并和同样选码数量的随机基准比较。当前版本是离线演示聊天，还没有连接在线 AI；你可以在日志页记录真实数据。")
                    input = ""
                }
            }, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) { Text("发送") }
        }
    }
}

@Composable
fun StatsScreen(trials: List<Trial>) {
    val valid = trials.filter { it.result in 1..49 }
    val hits = valid.count { t -> t.pick.split(",", " ").mapNotNull { it.trim().toIntOrNull() }.contains(t.result) }
    val pickCount = valid.map { it.pick.split(",", " ").mapNotNull(String::toIntOrNull).distinct().size }.average().takeIf { !it.isNaN() } ?: 0.0
    val baseline = pickCount / 49.0 * 100.0
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("样本概览", fontWeight = FontWeight.Bold, color = Ink)
            Metric("已记录开奖", "${valid.size} 期")
            Metric("命中至少一个", "$hits 期")
            Metric("实际命中率", if (valid.isEmpty()) "—" else String.format("%.2f%%", hits * 100.0 / valid.size))
            Metric("近似随机基准", if (pickCount == 0.0) "—" else String.format("%.2f%%", baseline))
        }
        Panel {
            Text("如何解读", fontWeight = FontWeight.Bold, color = Ink)
            Text("这里的命中率只统计你记录的每期选号是否包含特码。随机基准按平均每期选取 k 个不同号码时 k/49 近似计算。样本少时波动很大；数据需在开奖前固定，不能事后补选。", modifier = Modifier.padding(top = 8.dp), color = Color(0xFF687386))
        }
        if (valid.isEmpty()) Panel { Text("还没有记录", fontWeight = FontWeight.Bold); Text("去「日志」添加期号、选号和实际特码，就会开始累计。", modifier = Modifier.padding(top = 6.dp)) }
    }
}

@Composable
fun Metric(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color(0xFF687386)); Text(value, fontWeight = FontWeight.Bold, color = Ink) }
}

@Composable
fun LogScreen(trials: List<Trial>, save: (List<Trial>) -> Unit) {
    var issue by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("新增研究记录", fontWeight = FontWeight.Bold, color = Ink)
            Text("选号请用逗号分隔，例如 18, 23, 32。请在开奖前先保存选号。", color = Color(0xFF687386), modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
            OutlinedTextField(issue, { issue = it }, label = { Text("期号（必填）") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(date, { date = it }, label = { Text("开奖日期（可选）") }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("YYYY-MM-DD") })
            OutlinedTextField(pick, { pick = it }, label = { Text("预先固定的选号") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(result, { result = it }, label = { Text("实际特码 1–49") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            if (error.isNotBlank()) Text(error, color = Color.Red, modifier = Modifier.padding(top = 6.dp))
            Button(onClick = {
                val nums = pick.split(",", " ").mapNotNull { it.trim().toIntOrNull() }
                val actual = result.toIntOrNull()
                error = when {
                    issue.isBlank() -> "请填写期号。"
                    nums.isEmpty() || nums.any { it !in 1..49 } || nums.distinct().size != nums.size -> "选号须为 1–49 之间不重复的号码，用逗号分隔。"
                    actual == null || actual !in 1..49 -> "实际特码须为 1–49。"
                    trials.any { it.issue == issue.trim() } -> "这个期号已经记录过啦，请检查是否重复。"
                    else -> ""
                }
                if (error.isBlank() && actual != null) {
                    save((trials + Trial(issue.trim(), nums.joinToString(","), actual, date.trim())).sortedBy { it.issue })
                    issue = ""; pick = ""; result = ""; date = ""
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("保存记录") }
        }
        Text("历史记录 · ${trials.size} 期", fontWeight = FontWeight.Bold, color = Ink)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(trials.reversed()) { t ->
                val picked = t.pick.split(",").mapNotNull(String::toIntOrNull)
                Panel {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("${t.issue}  ${t.date}", fontWeight = FontWeight.Bold); Text(if (picked.contains(t.result)) "命中 🎉" else "未命中", color = if (picked.contains(t.result)) Color(0xFF27816D) else Color(0xFF687386)) }
                    Text("选号：${t.pick}  ·  特码：${t.result}", modifier = Modifier.padding(top = 5.dp))
                    TextButton(onClick = { save(trials.filterNot { it.issue == t.issue }) }) { Text("删除记录") }
                }
            }
        }
    }
}

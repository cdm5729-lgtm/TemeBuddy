# 特码小伙伴（Android 项目源码）

一个面向 Android 的可爱机器人风格研究助手原型：聊天演示、开奖记录、命中率与随机基准概览。数据保存在本机 SharedPreferences 中。

## 当前版本状态
- **APK：尚未生成。** 当前交付的是可在 Android Studio 打开的项目源码，不是已经编译或测试的 APK。
- 聊天页目前使用离线演示回复，**没有连接真正的在线 AI**。
- 不会自动抓取开奖数据；用户需要在日志页录入并核对真实数据。
- 统计仅反映手工录入的数据；期号排序当前按文本排序，建议保持期号格式统一。

## 构建 APK
1. 在电脑安装 Android Studio（建议近期稳定版）和 Android SDK Platform 35。
2. 解压项目文件夹 `TemeBuddy`。
3. Android Studio 选择 **Open**，打开 `TemeBuddy` 文件夹，等待 Gradle Sync。
4. 若提示安装 Android Gradle Plugin / SDK 组件，按 IDE 提示安装；需联网下载依赖。
5. 菜单选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
6. 构建成功后点击通知中的 **locate**，通常 APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。
7. 将 APK 传到 Android 手机并打开安装。若系统拦截，进入系统设置，只对这次使用的文件管理器/浏览器允许“安装未知应用”，安装后可关闭该权限。

也可在项目根目录运行（需安装 Gradle/Android SDK）：
```bash
gradle assembleDebug
```

## 真正的 AI 聊天怎么接
推荐架构：Android App → 你控制的 HTTPS 后端 → AI 服务 API。不要把 API 密钥硬编码进 APK；APK 可被反编译，密钥会泄露。后端应设置认证、速率限制、费用上限与隐私说明。配置后端前，本项目保留离线演示回复。

## 数据来源与统计限制
- 本应用不内置或声称拥有官方开奖记录；所有记录都需要你核验来源并手工录入。
- 历史频数、冷热号和遗漏值不能保证下一期结果。假设从 1–49 中独立均匀开出一个特码，每期选 k 个不重复号码，随机命中至少一个的概率是 k/49。
- 研究时应在开奖前固定选号，完整保留命中与未命中，并与相同选码数量的随机基准比较。小样本中的涨跌可能只是随机波动。
